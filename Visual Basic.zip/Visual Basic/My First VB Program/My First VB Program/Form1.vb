﻿Public Class Form1
    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        Button1.BackColor = Color.Beige
        Button1.Text = Int(Rnd() * 10)
    End Sub
End Class
