﻿Public Class Form1
    Private Sub HScrollBar1_Scroll(sender As Object, e As ScrollEventArgs) Handles HScrollBar1.Scroll
        PictureBox1.Visible = False
        LVBar.Location = New Point(21 + HScrollBar1.Value, -1)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        PictureBox1.Visible = True
        PictureBox1.Location = New Point(LVBar.Location.X - 17, LHBar.Location.Y - 17)
    End Sub
End Class
