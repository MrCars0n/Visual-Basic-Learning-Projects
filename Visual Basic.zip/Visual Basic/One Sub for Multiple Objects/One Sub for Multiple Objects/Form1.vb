﻿Public Class Form1

    Dim turnCount As Integer

    Private Sub RadioClick(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged,
            RadioButton2.CheckedChanged,
            RadioButton3.CheckedChanged,
            RadioButton4.CheckedChanged,
            RadioButton5.CheckedChanged
        If sender.backcolor = Me.BackColor Then
            sender.backcolor = Color.Yellow
        Else
            sender.backcolor = Me.BackColor
        End If
    End Sub

    Private Sub ButtonClick(sender As Object, e As EventArgs) Handles Button1.Click,
            Button2.Click, Button3.Click, Button4.Click, Button5.Click,
            Button6.Click, Button7.Click, Button8.Click, Button9.Click

        If turnCount Mod 2 = 0 Then
            sender.text = "X"
        Else
            sender.text = "O"
        End If

        turnCount += 1
    End Sub
End Class
