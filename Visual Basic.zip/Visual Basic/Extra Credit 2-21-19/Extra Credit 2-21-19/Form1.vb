﻿Public Class Form1
    Private Sub StartToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StartToolStripMenuItem.Click
        Timer1.Enabled = True

    End Sub

    Private Sub StopToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StopToolStripMenuItem.Click
        Timer1.Enabled = False
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If Timer1.Interval = 1000 Then
            Label1.Text = 1
        End If
        If Timer1.Interval = 2000 Then
            Label1.Text = 2
        End If
    End Sub
End Class
