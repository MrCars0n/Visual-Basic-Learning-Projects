﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        MsgBox("This is a message box!")

        Dim choice As Integer
        choice = MsgBox("Do you want it to snow?", MsgBoxStyle.YesNo)

        If choice = vbYes Then
            Button1.Text = "SNOW!"
        Else
            Button1.Text = "BOOO!"
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim name As String

        name = InputBox("What is your name?")

        Button2.Text = "Hello " + name
    End Sub
End Class
