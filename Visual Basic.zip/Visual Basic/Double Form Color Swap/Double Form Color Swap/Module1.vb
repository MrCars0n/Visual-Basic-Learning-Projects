﻿Module Module1
    Dim Form1Click As Boolean
End Module
