﻿Public Class Form2
    Private Sub Form2_Click(sender As Object, e As EventArgs) Handles Me.Click
        Me.BackColor = Color.Green
        Form1.BackColor = Color.Red
    End Sub
End Class