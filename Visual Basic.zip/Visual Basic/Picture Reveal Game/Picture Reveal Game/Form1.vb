﻿Public Class Form1

    Dim clickCount As Integer
    Dim chances As Integer
    Dim playagain As String
    Dim firstSender As Button
    Dim secondSender As Button

    Private Sub ButtonClick(sender As Object, e As EventArgs) Handles Button1.Click,
            Button2.Click, Button3.Click, Button4.Click, Button5.Click,
            Button6.Click, Button7.Click, Button8.Click, Button9.Click
        sender.Visible = False
        If clickCount Mod 2 = 0 Then
            firstSender = sender
        Else
            secondSender = sender

            If firstSender.Tag <> secondSender.Tag And chances > 0 Then
                firstSender.Visible = False
                secondSender.Visible = False
                chances = chances - 1
            ElseIf chances > 0 Then
                playagain = MsgBox("You lost")
                Me.Close()
            End If
        End If
        clickCount = clickCount + 1
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        chances = 3
    End Sub
End Class
