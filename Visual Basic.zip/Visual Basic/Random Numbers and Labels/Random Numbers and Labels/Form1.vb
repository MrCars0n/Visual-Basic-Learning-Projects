﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim d1 As Integer
        Dim d2 As Integer
        Dim sum As Integer

        d1 = Int(Rnd() * 6) + 1
        d2 = Int(Rnd() * 6) + 1
        sum = d1 + d2

        Label1.Text = d1
        Label2.Text = d2
        Label3.Text = sum
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Randomize()
    End Sub
End Class
