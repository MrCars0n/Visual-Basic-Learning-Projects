﻿Public Class Form1
    Private Sub TimeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TimeToolStripMenuItem.Click
        Label1.Text = TimeString
    End Sub

    Private Sub DateToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DateToolStripMenuItem.Click
        Label1.Text = DateString
    End Sub

    Private Sub DayToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DayToolStripMenuItem.Click
        Label1.Text = Now.DayOfWeek
    End Sub

    Private Sub MonthToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MonthToolStripMenuItem.Click
        Label1.Text = Now.Month
    End Sub
End Class
