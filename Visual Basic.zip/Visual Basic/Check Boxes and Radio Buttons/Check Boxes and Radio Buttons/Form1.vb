﻿Public Class Form1
    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox2.Checked = True Then
            Me.Width = 757
        ElseIf CheckBox1.Checked = True Then
            Me.Width = 473
        Else
            Me.Width = 200
        End If
        If CheckBox1.Checked = True Then
            GroupBox1.Visible = True
        ElseIf CheckBox2.Checked = True Then
            Me.Width = 757
        Else
            Me.Width = 200
            GroupBox1.Visible = False
        End If
    End Sub

    Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox2.CheckedChanged
        If CheckBox2.Checked = True Then
            GroupBox2.Visible = True
            Me.Width = 757
        ElseIf CheckBox1.Checked = True Then
            Me.Width = 473
        Else
            Me.Width = 200
            GroupBox2.Visible = False
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If RadioButton1.Checked = True Then
            MsgBox("Yay delays!")
        End If

        If RadioButton2.Checked Then
            MsgBox("Boo on you!")
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If RadioButton3.Checked = True Then
            MsgBox("Brrr!")
        End If

        If RadioButton4.Checked = True Then
            MsgBox("You're crazy!")
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Width = 200
    End Sub
End Class
