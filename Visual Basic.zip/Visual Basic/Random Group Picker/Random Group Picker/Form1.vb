﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        ListBox2.Items.Clear()
        ListBox3.Items.Clear()
        ListBox4.Items.Clear()
        ListBox5.Items.Clear()
        ListBox6.Items.Clear()

        For x = 1 To 5
            ListBox1.SelectedIndex = Int(Rnd() * ListBox1.Items.Count)
            ListBox2.Items.Add(ListBox1.SelectedItem)
            ListBox1.Items.Remove(ListBox1.SelectedItem)
        Next

        For x = 1 To 5
            ListBox1.SelectedIndex = Int(Rnd() * ListBox1.Items.Count)
            ListBox3.Items.Add(ListBox1.SelectedItem)
            ListBox1.Items.Remove(ListBox1.SelectedItem)
        Next

        For x = 1 To 5
            ListBox1.SelectedIndex = Int(Rnd() * ListBox1.Items.Count)
            ListBox4.Items.Add(ListBox1.SelectedItem)
            ListBox1.Items.Remove(ListBox1.SelectedItem)
        Next

        For x = 1 To 5
            ListBox1.SelectedIndex = Int(Rnd() * ListBox1.Items.Count)
            ListBox5.Items.Add(ListBox1.SelectedItem)
            ListBox1.Items.Remove(ListBox1.SelectedItem)
        Next

        For x = 1 To 5
            ListBox1.SelectedIndex = Int(Rnd() * ListBox1.Items.Count)
            ListBox6.Items.Add(ListBox1.SelectedItem)
            ListBox1.Items.Remove(ListBox1.SelectedItem)
        Next

        ' Copy all of the names from the hidden list back to your original
        ListBox1.Items.AddRange(ListBox7.Items)
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Randomize()
    End Sub
End Class
