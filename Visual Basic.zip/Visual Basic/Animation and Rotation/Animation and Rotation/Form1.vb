﻿Public Class Form1

    Dim screen As Graphics
    Dim word As String

    ' 32-bit color contains the following four variables
    '  (4 variables with 8 bits each would be 32 bits)
    Dim alpha As Byte
    Dim red As Byte
    Dim green As Byte
    Dim blue As Byte

    Dim myColor As Color
    Dim myBrush As SolidBrush
    Dim myFont As Font
    Dim fontSize As Integer
    Dim angle As Integer

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Set up the ability to use graphics in VB
        screen = Me.CreateGraphics

        ' Move the origin to the center of the form
        screen.TranslateTransform(Me.Width / 2, Me.Height / 2)

        ' Only put once in form load to ensure true randoms
        Randomize()

        ' Can't start a font size as 0
        fontSize = 1
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        word = InputBox("Please enter a word")

        ' Animation requires a timer - turn it on here!

        Timer1.Enabled = True
        fontSize = 1
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ' This code executes every itnerval (aka every 1 millisecond)

        alpha = Int(Rnd() * 256)
        red = Int(Rnd() * 256)
        blue = Int(Rnd() * 256)
        green = Int(Rnd() * 256)
        myColor = Color.FromArgb(alpha, red, green, blue)
        myBrush = New SolidBrush(myColor)
        myFont = New Font("Comic Sans MS", fontSize)

        screen.DrawString(word, myFont, myBrush, 0, 0)
        fontSize = fontSize + 1
        screen.RotateTransform(angle)
        angle = angle + 1
    End Sub
End Class
