﻿Public Class Form2

    Dim dx, dy, jumpingDY, jumpingCount As Integer        'Player Movement;     Jump Force;     Jump Duration

    Dim platform(0 To 3) As Label                         'Array representing platforms
    Dim onPlatform, jumping As Boolean  'True/False - standing on something;  jumping

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Randomize()
        dx = 0
        dy = 2      '1 = Force of gravity

        jumpingDY = -2 - dy 'Opposite of gravity (dy) + stronger

        platform(0) = Ground
        platform(1) = Platform1
        platform(2) = Platform2
        platform(3) = Platform3
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Player.Left += dx

        If Form1.mushroomTouch = True And Form1.playerColor = True Then
            Player.BackColor = Color.FromArgb(Int(Rnd() * 256), Int(Rnd() * 256), Int(Rnd() * 256))
            Player.Width = Form1.Player.Width
            Player.Height = Form1.Player.Height
        Else
            Player.BackColor = Color.Crimson
        End If

        If Player.Left < 0 Or Player.Right > Me.Width Then
            dx = -dx
        End If

        'Assume NOT standing on something
        onPlatform = False

        For x = 0 To 3
            If Player.Bounds.IntersectsWith(platform(x).Bounds) Then
                onPlatform = True
            End If
        Next

        If onPlatform = False Then
            Player.Top += dy
        End If

        ' Jumping Section
        If jumping = True Then
            Player.Top = Player.Top + jumpingDY

            jumpingCount += 1
            If jumpingCount = 30 Then
                jumping = False
                jumpingCount = 0
            End If
        End If

        ' Transition between forms (form1 to form2)
        If Player.Bounds.IntersectsWith(LeftWall.Bounds) Then
            ' TURN OFF CURRENT FORM TIMER
            Timer1.Enabled = False
            Me.Hide()

            ' STOP PLAYER MOVEMENT & START PLAYER AWAY FROM BOUNDARY
            dx = 0
            Player.Left = 5

            Form1.Player.Top = Player.Top + (Form1.Player.Height - Player.Height)

            ' Start 2nd form
            Form1.Timer1.Enabled = True
            Form1.Show()
        End If

        ' Detect collision with key
        If Player.Bounds.IntersectsWith(Key.Bounds) Then
            hasKey = True
            Key.Visible = False
        End If
    End Sub

    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Right Then
            dx = 3
        End If

        If e.KeyCode = Keys.Left Then
            dx = -3
        End If

        ' Only allow jump if on platform
        If e.KeyCode = Keys.Up And onPlatform = True Then
            jumping = True
        End If

        If e.KeyCode = Keys.C Then
            If colorSwitch = False Then
                Form1.playerColor = False
                colorSwitch = True
            ElseIf colorSwitch = True Then
                Form1.playerColor = True
                colorSwitch = False
            End If
        End If
    End Sub

    Private Sub Form1_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp
        If e.KeyCode = Keys.Left Or e.KeyCode = Keys.Right Then
            dx = 0
        End If

        If e.KeyCode = Keys.Up Then
            jumping = False
            jumpingCount = 0
        End If
    End Sub

    Private Sub Form2_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        End
    End Sub
End Class
