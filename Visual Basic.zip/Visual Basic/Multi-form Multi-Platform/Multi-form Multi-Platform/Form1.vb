﻿Public Class Form1

    Dim dx, dy, jumpingDY, jumpingCount As Integer        'Player Movement;     Jump Force;     Jump Duration

    Dim platform(0 To 3) As Label                         'Array representing platforms
    Public onPlatform, jumping, mushroomTouch, playerColor As Boolean  'True/False - standing on something;  jumping

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Randomize()
        mushroomTouch = False
        playerColor = False
        dx = 0
        dy = 2      '1 = Force of gravity

        jumpingDY = -2 - dy 'Opposite of gravity (dy) + stronger

        platform(0) = Ground
        platform(1) = Platform1
        platform(2) = Platform2
        platform(3) = Platform3

        hasKey = False

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Player.Left += dx

        If Player.Left < 0 Or Player.Right > Me.Width Then
            dx = -dx
        End If

        If Player.Bounds.IntersectsWith(Mushroom.Bounds) And mushroomTouch = False Then
            Player.Width += 50
            Player.Height += 50
            Player.Top -= 50
            Player.Left -= 25
            Mushroom.Visible = False
            mushroomTouch = True
            playerColor = True
        End If

        If mushroomTouch = True And playerColor = True Then
            Player.BackColor = Color.FromArgb(Int(Rnd() * 256), Int(Rnd() * 256), Int(Rnd() * 256))
        Else
            Player.BackColor = Color.Crimson
        End If

        'Assume NOT standing on something
        onPlatform = False

        For x = 0 To 3
            If Player.Bounds.IntersectsWith(platform(x).Bounds) Then
                onPlatform = True
            End If
        Next

        If onPlatform = False Then
            Player.Top += dy
        End If

        ' Jumping Section
        If jumping = True Then
            Player.Top = Player.Top + jumpingDY

            jumpingCount += 1
            If jumpingCount = 30 Then
                jumping = False
                jumpingCount = 0
            End If
        End If

        ' Transition between forms (form1 to form2)
        If Player.Bounds.IntersectsWith(RightWall.Bounds) Then
            ' TURN OFF CURRENT FORM TIMER
            Timer1.Enabled = False
            Me.Hide()

            ' STOP PLAYER MOVEMENT & START PLAYER AWAY FROM BOUNDARY
            dx = 0
            If mushroomTouch = False Then
                Player.Left = 758
            Else
                Player.Left = 708
            End If

            ' Same height on both forms
            Player.Top = Form2.Player.Top

            ' Start 2nd form
            Form2.Timer1.Enabled = True
            Form2.Show()
        End If

        ' if have key, touch door and win
        If Player.Bounds.IntersectsWith(Door.Bounds) And hasKey = True Then
            Timer1.Enabled = False
            Player.Visible = False
            MsgBox("Congratulations, you win!!!")
        End If
    End Sub

    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Right Then
            dx = 3
        End If

        If e.KeyCode = Keys.Left Then
            dx = -3
        End If

        ' Only allow jump if on platform
        If e.KeyCode = Keys.Up And onPlatform = True Then
            jumping = True
        End If

        If e.KeyCode = Keys.C Then
            If colorSwitch = False Then
                playerColor = False
                colorSwitch = True
            ElseIf colorSwitch = True Then
                playerColor = True
                colorSwitch = False
            End If
        End If
    End Sub

    Private Sub Form1_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp
        If e.KeyCode = Keys.Left Or e.KeyCode = Keys.Right Then
            dx = 0
        End If

        If e.KeyCode = Keys.Up Then
            jumping = False
            jumpingCount = 0
        End If
    End Sub
End Class
