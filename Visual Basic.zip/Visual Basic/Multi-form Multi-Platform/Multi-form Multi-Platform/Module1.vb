﻿' Global Variables Here
Module Module1
    ' We sya PUBLIC, dot DIM
    Public hasKey, colorSwitch As Boolean
End Module
