﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Ground = New System.Windows.Forms.Label()
        Me.Platform1 = New System.Windows.Forms.Label()
        Me.Platform2 = New System.Windows.Forms.Label()
        Me.Platform3 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Mushroom = New System.Windows.Forms.PictureBox()
        Me.RightWall = New System.Windows.Forms.Label()
        Me.Player = New System.Windows.Forms.Label()
        Me.Door = New System.Windows.Forms.Label()
        CType(Me.Mushroom, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Ground
        '
        Me.Ground.BackColor = System.Drawing.Color.ForestGreen
        Me.Ground.Image = Global.Multi_form_Multi_Platform.My.Resources.Resources.grass
        Me.Ground.Location = New System.Drawing.Point(-28, 404)
        Me.Ground.Name = "Ground"
        Me.Ground.Size = New System.Drawing.Size(855, 64)
        Me.Ground.TabIndex = 0
        '
        'Platform1
        '
        Me.Platform1.BackColor = System.Drawing.Color.ForestGreen
        Me.Platform1.Image = Global.Multi_form_Multi_Platform.My.Resources.Resources.grass
        Me.Platform1.Location = New System.Drawing.Point(116, 297)
        Me.Platform1.Name = "Platform1"
        Me.Platform1.Size = New System.Drawing.Size(178, 17)
        Me.Platform1.TabIndex = 1
        '
        'Platform2
        '
        Me.Platform2.BackColor = System.Drawing.Color.ForestGreen
        Me.Platform2.Image = Global.Multi_form_Multi_Platform.My.Resources.Resources.grass
        Me.Platform2.Location = New System.Drawing.Point(411, 223)
        Me.Platform2.Name = "Platform2"
        Me.Platform2.Size = New System.Drawing.Size(178, 17)
        Me.Platform2.TabIndex = 2
        '
        'Platform3
        '
        Me.Platform3.BackColor = System.Drawing.Color.ForestGreen
        Me.Platform3.Image = Global.Multi_form_Multi_Platform.My.Resources.Resources.grass
        Me.Platform3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Platform3.Location = New System.Drawing.Point(186, 133)
        Me.Platform3.Name = "Platform3"
        Me.Platform3.Size = New System.Drawing.Size(178, 17)
        Me.Platform3.TabIndex = 3
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1
        '
        'Mushroom
        '
        Me.Mushroom.BackColor = System.Drawing.Color.Transparent
        Me.Mushroom.Image = Global.Multi_form_Multi_Platform.My.Resources.Resources.mushroom
        Me.Mushroom.Location = New System.Drawing.Point(538, 174)
        Me.Mushroom.Name = "Mushroom"
        Me.Mushroom.Size = New System.Drawing.Size(50, 50)
        Me.Mushroom.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Mushroom.TabIndex = 5
        Me.Mushroom.TabStop = False
        '
        'RightWall
        '
        Me.RightWall.BackColor = System.Drawing.Color.White
        Me.RightWall.Location = New System.Drawing.Point(795, -3)
        Me.RightWall.Name = "RightWall"
        Me.RightWall.Size = New System.Drawing.Size(10, 409)
        Me.RightWall.TabIndex = 12
        Me.RightWall.Visible = False
        '
        'Player
        '
        Me.Player.BackColor = System.Drawing.Color.Crimson
        Me.Player.Location = New System.Drawing.Point(116, 133)
        Me.Player.Name = "Player"
        Me.Player.Size = New System.Drawing.Size(35, 35)
        Me.Player.TabIndex = 4
        '
        'Door
        '
        Me.Door.BackColor = System.Drawing.Color.Gold
        Me.Door.Location = New System.Drawing.Point(12, 331)
        Me.Door.Name = "Door"
        Me.Door.Size = New System.Drawing.Size(40, 74)
        Me.Door.TabIndex = 13
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SkyBlue
        Me.BackgroundImage = Global.Multi_form_Multi_Platform.My.Resources.Resources.Capture
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Door)
        Me.Controls.Add(Me.RightWall)
        Me.Controls.Add(Me.Mushroom)
        Me.Controls.Add(Me.Player)
        Me.Controls.Add(Me.Platform3)
        Me.Controls.Add(Me.Platform2)
        Me.Controls.Add(Me.Platform1)
        Me.Controls.Add(Me.Ground)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Level 1"
        CType(Me.Mushroom, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Ground As Label
    Friend WithEvents Platform1 As Label
    Friend WithEvents Platform2 As Label
    Friend WithEvents Platform3 As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Mushroom As PictureBox
    Friend WithEvents RightWall As Label
    Friend WithEvents Player As Label
    Friend WithEvents Door As Label
End Class
