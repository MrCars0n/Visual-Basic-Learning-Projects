﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Player = New System.Windows.Forms.Label()
        Me.Platform3 = New System.Windows.Forms.Label()
        Me.Platform2 = New System.Windows.Forms.Label()
        Me.Platform1 = New System.Windows.Forms.Label()
        Me.Ground = New System.Windows.Forms.Label()
        Me.LeftWall = New System.Windows.Forms.Label()
        Me.Key = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1
        '
        'Player
        '
        Me.Player.BackColor = System.Drawing.Color.Crimson
        Me.Player.Location = New System.Drawing.Point(7, 371)
        Me.Player.Name = "Player"
        Me.Player.Size = New System.Drawing.Size(35, 35)
        Me.Player.TabIndex = 10
        '
        'Platform3
        '
        Me.Platform3.BackColor = System.Drawing.Color.ForestGreen
        Me.Platform3.Image = Global.Multi_form_Multi_Platform.My.Resources.Resources.grass
        Me.Platform3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Platform3.Location = New System.Drawing.Point(312, 230)
        Me.Platform3.Name = "Platform3"
        Me.Platform3.Size = New System.Drawing.Size(178, 17)
        Me.Platform3.TabIndex = 9
        '
        'Platform2
        '
        Me.Platform2.BackColor = System.Drawing.Color.ForestGreen
        Me.Platform2.Image = Global.Multi_form_Multi_Platform.My.Resources.Resources.grass
        Me.Platform2.Location = New System.Drawing.Point(577, 321)
        Me.Platform2.Name = "Platform2"
        Me.Platform2.Size = New System.Drawing.Size(178, 17)
        Me.Platform2.TabIndex = 8
        '
        'Platform1
        '
        Me.Platform1.BackColor = System.Drawing.Color.ForestGreen
        Me.Platform1.Image = Global.Multi_form_Multi_Platform.My.Resources.Resources.grass
        Me.Platform1.Location = New System.Drawing.Point(86, 135)
        Me.Platform1.Name = "Platform1"
        Me.Platform1.Size = New System.Drawing.Size(178, 17)
        Me.Platform1.TabIndex = 7
        '
        'Ground
        '
        Me.Ground.BackColor = System.Drawing.Color.ForestGreen
        Me.Ground.Image = Global.Multi_form_Multi_Platform.My.Resources.Resources.grass
        Me.Ground.Location = New System.Drawing.Point(-28, 406)
        Me.Ground.Name = "Ground"
        Me.Ground.Size = New System.Drawing.Size(855, 64)
        Me.Ground.TabIndex = 6
        '
        'LeftWall
        '
        Me.LeftWall.BackColor = System.Drawing.Color.White
        Me.LeftWall.Location = New System.Drawing.Point(-5, -3)
        Me.LeftWall.Name = "LeftWall"
        Me.LeftWall.Size = New System.Drawing.Size(10, 409)
        Me.LeftWall.TabIndex = 13
        Me.LeftWall.Visible = False
        '
        'Key
        '
        Me.Key.BackColor = System.Drawing.Color.Purple
        Me.Key.Location = New System.Drawing.Point(7, 57)
        Me.Key.Name = "Key"
        Me.Key.Size = New System.Drawing.Size(24, 28)
        Me.Key.TabIndex = 14
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SkyBlue
        Me.BackgroundImage = Global.Multi_form_Multi_Platform.My.Resources.Resources.Sky
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Key)
        Me.Controls.Add(Me.LeftWall)
        Me.Controls.Add(Me.Player)
        Me.Controls.Add(Me.Platform3)
        Me.Controls.Add(Me.Platform2)
        Me.Controls.Add(Me.Platform1)
        Me.Controls.Add(Me.Ground)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Level 2"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Player As Label
    Friend WithEvents Platform3 As Label
    Friend WithEvents Platform2 As Label
    Friend WithEvents Platform1 As Label
    Friend WithEvents Ground As Label
    Friend WithEvents LeftWall As Label
    Friend WithEvents Key As Label
End Class
