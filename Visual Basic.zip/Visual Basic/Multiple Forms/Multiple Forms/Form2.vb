﻿Public Class Form2
    Private Sub Form2_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        ' To have the ability to close the program when you close the other form, put END here
        End
    End Sub
End Class