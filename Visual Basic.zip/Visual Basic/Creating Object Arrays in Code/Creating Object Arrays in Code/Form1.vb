﻿Public Class Form1

    ' This creates an array (ordered list) of 500 buttons
    Dim myButton(0 To 499) As Button

    ' The cyrrent button in the timer
    Dim count As Integer

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Randomize()
    End Sub

    Private Sub Form1_Click(sender As Object, e As EventArgs) Handles Me.Click
        ' Arrays go hand in have with FOR LOOPS
        For n = 0 To 499
            ' "Spawn" a new button
            myButton(n) = New Button
            ' Set all of the properties you'd like to change
            ' Location, color, size, etc...
            myButton(n).BackColor = Color.FromArgb(Int(Rnd() * 256), Int(Rnd() * 256), Int(Rnd() * 256))
            myButton(n).Height = Int(Rnd() * 100)
            myButton(n).Width = Int(Rnd() * 100)
            myButton(n).Left = Int(Rnd() * Me.Width)
            myButton(n).Top = Int(Rnd() * Me.Height)

            ' We must add each button to the form
            Me.Controls.Add(myButton(n))

        Next
        Me.BackColor = Color.FromArgb(Int(Rnd() * 256), Int(Rnd() * 256), Int(Rnd() * 256))
    End Sub

    Private Sub OnToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OnToolStripMenuItem.Click
        Timer1.Enabled = True
    End Sub

    Private Sub OffToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OffToolStripMenuItem.Click
        Timer1.Enabled = False
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ' In here, we have all of the code from above (in the form click)
        ' EXCEPT FOR THE LOOP ITSELF

        myButton(count) = New Button
        ' Set all of the properties you'd like to change
        ' Location, color, size, etc...
        myButton(count).BackColor = Color.FromArgb(Int(Rnd() * 256), Int(Rnd() * 256), Int(Rnd() * 256))
        myButton(count).Height = Int(Rnd() * 100)
        myButton(count).Width = Int(Rnd() * 100)
        myButton(count).Left = Int(Rnd() * Me.Width)
        myButton(count).Top = Int(Rnd() * Me.Height)
        myButton(count).Text = count

        ' We must add each button to the form
        Me.Controls.Add(myButton(count))

        ' Go to the next count
        count = count + 1

        ' Check to make sure you do not exceed the buttom limit (499)
        If count >= 500 Then
            count = 0
        End If
    End Sub
End Class
