﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.BTnum1 = New System.Windows.Forms.Button()
        Me.BTnum2 = New System.Windows.Forms.Button()
        Me.BTnum3 = New System.Windows.Forms.Button()
        Me.BTnum6 = New System.Windows.Forms.Button()
        Me.BTnum5 = New System.Windows.Forms.Button()
        Me.BTnum4 = New System.Windows.Forms.Button()
        Me.BTnum9 = New System.Windows.Forms.Button()
        Me.BTnum8 = New System.Windows.Forms.Button()
        Me.BTnum7 = New System.Windows.Forms.Button()
        Me.BTnum0 = New System.Windows.Forms.Button()
        Me.BTdecimalpnt = New System.Windows.Forms.Button()
        Me.BTadd = New System.Windows.Forms.Button()
        Me.BTdivide = New System.Windows.Forms.Button()
        Me.BTmultiply = New System.Windows.Forms.Button()
        Me.BTsubtract = New System.Windows.Forms.Button()
        Me.BTclearAll = New System.Windows.Forms.Button()
        Me.BTclearCurrent = New System.Windows.Forms.Button()
        Me.BTe = New System.Windows.Forms.Button()
        Me.BTpi = New System.Windows.Forms.Button()
        Me.BTposNegSwitch = New System.Windows.Forms.Button()
        Me.BTsqrt = New System.Windows.Forms.Button()
        Me.BTneg1pow = New System.Windows.Forms.Button()
        Me.BTsubmit = New System.Windows.Forms.Button()
        Me.BTtan = New System.Windows.Forms.Button()
        Me.BTcos = New System.Windows.Forms.Button()
        Me.BTsin = New System.Windows.Forms.Button()
        Me.BTlog = New System.Windows.Forms.Button()
        Me.BTln = New System.Windows.Forms.Button()
        Me.BTsq = New System.Windows.Forms.Button()
        Me.BTfactorial = New System.Windows.Forms.Button()
        Me.BTarcSin = New System.Windows.Forms.Button()
        Me.BTarcCos = New System.Windows.Forms.Button()
        Me.BTarcTan = New System.Windows.Forms.Button()
        Me.BTcb = New System.Windows.Forms.Button()
        Me.BTcbrt = New System.Windows.Forms.Button()
        Me.BTpowY = New System.Windows.Forms.Button()
        Me.BTrootY = New System.Windows.Forms.Button()
        Me.BTpowTen = New System.Windows.Forms.Button()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(14, 12)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(532, 47)
        Me.TextBox1.TabIndex = 0
        Me.TextBox1.Text = "0"
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'BTnum1
        '
        Me.BTnum1.BackColor = System.Drawing.Color.White
        Me.BTnum1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTnum1.Location = New System.Drawing.Point(272, 235)
        Me.BTnum1.Name = "BTnum1"
        Me.BTnum1.Size = New System.Drawing.Size(50, 50)
        Me.BTnum1.TabIndex = 1
        Me.BTnum1.Text = "1"
        Me.BTnum1.UseVisualStyleBackColor = False
        '
        'BTnum2
        '
        Me.BTnum2.BackColor = System.Drawing.Color.White
        Me.BTnum2.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTnum2.Location = New System.Drawing.Point(328, 233)
        Me.BTnum2.Name = "BTnum2"
        Me.BTnum2.Size = New System.Drawing.Size(50, 50)
        Me.BTnum2.TabIndex = 2
        Me.BTnum2.Text = "2"
        Me.BTnum2.UseVisualStyleBackColor = False
        '
        'BTnum3
        '
        Me.BTnum3.BackColor = System.Drawing.Color.White
        Me.BTnum3.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTnum3.Location = New System.Drawing.Point(384, 233)
        Me.BTnum3.Name = "BTnum3"
        Me.BTnum3.Size = New System.Drawing.Size(50, 50)
        Me.BTnum3.TabIndex = 3
        Me.BTnum3.Text = "3"
        Me.BTnum3.UseVisualStyleBackColor = False
        '
        'BTnum6
        '
        Me.BTnum6.BackColor = System.Drawing.Color.White
        Me.BTnum6.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTnum6.Location = New System.Drawing.Point(384, 177)
        Me.BTnum6.Name = "BTnum6"
        Me.BTnum6.Size = New System.Drawing.Size(50, 50)
        Me.BTnum6.TabIndex = 6
        Me.BTnum6.Text = "6"
        Me.BTnum6.UseVisualStyleBackColor = False
        '
        'BTnum5
        '
        Me.BTnum5.BackColor = System.Drawing.Color.White
        Me.BTnum5.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTnum5.Location = New System.Drawing.Point(328, 177)
        Me.BTnum5.Name = "BTnum5"
        Me.BTnum5.Size = New System.Drawing.Size(50, 50)
        Me.BTnum5.TabIndex = 5
        Me.BTnum5.Text = "5"
        Me.BTnum5.UseVisualStyleBackColor = False
        '
        'BTnum4
        '
        Me.BTnum4.BackColor = System.Drawing.Color.White
        Me.BTnum4.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTnum4.Location = New System.Drawing.Point(272, 177)
        Me.BTnum4.Name = "BTnum4"
        Me.BTnum4.Size = New System.Drawing.Size(50, 50)
        Me.BTnum4.TabIndex = 4
        Me.BTnum4.Text = "4"
        Me.BTnum4.UseVisualStyleBackColor = False
        '
        'BTnum9
        '
        Me.BTnum9.BackColor = System.Drawing.Color.White
        Me.BTnum9.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTnum9.Location = New System.Drawing.Point(384, 121)
        Me.BTnum9.Name = "BTnum9"
        Me.BTnum9.Size = New System.Drawing.Size(50, 50)
        Me.BTnum9.TabIndex = 9
        Me.BTnum9.Text = "9"
        Me.BTnum9.UseVisualStyleBackColor = False
        '
        'BTnum8
        '
        Me.BTnum8.BackColor = System.Drawing.Color.White
        Me.BTnum8.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTnum8.Location = New System.Drawing.Point(328, 121)
        Me.BTnum8.Name = "BTnum8"
        Me.BTnum8.Size = New System.Drawing.Size(50, 50)
        Me.BTnum8.TabIndex = 8
        Me.BTnum8.Text = "8"
        Me.BTnum8.UseVisualStyleBackColor = False
        '
        'BTnum7
        '
        Me.BTnum7.BackColor = System.Drawing.Color.White
        Me.BTnum7.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTnum7.Location = New System.Drawing.Point(272, 121)
        Me.BTnum7.Name = "BTnum7"
        Me.BTnum7.Size = New System.Drawing.Size(50, 50)
        Me.BTnum7.TabIndex = 7
        Me.BTnum7.Text = "7"
        Me.BTnum7.UseVisualStyleBackColor = False
        '
        'BTnum0
        '
        Me.BTnum0.BackColor = System.Drawing.Color.White
        Me.BTnum0.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTnum0.Location = New System.Drawing.Point(272, 287)
        Me.BTnum0.Name = "BTnum0"
        Me.BTnum0.Size = New System.Drawing.Size(106, 50)
        Me.BTnum0.TabIndex = 10
        Me.BTnum0.Text = "0"
        Me.BTnum0.UseVisualStyleBackColor = False
        '
        'BTdecimalpnt
        '
        Me.BTdecimalpnt.BackColor = System.Drawing.Color.White
        Me.BTdecimalpnt.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTdecimalpnt.Location = New System.Drawing.Point(384, 289)
        Me.BTdecimalpnt.Name = "BTdecimalpnt"
        Me.BTdecimalpnt.Size = New System.Drawing.Size(50, 50)
        Me.BTdecimalpnt.TabIndex = 11
        Me.BTdecimalpnt.Text = "."
        Me.BTdecimalpnt.UseVisualStyleBackColor = False
        '
        'BTadd
        '
        Me.BTadd.BackColor = System.Drawing.Color.White
        Me.BTadd.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTadd.Location = New System.Drawing.Point(440, 289)
        Me.BTadd.Name = "BTadd"
        Me.BTadd.Size = New System.Drawing.Size(50, 50)
        Me.BTadd.TabIndex = 15
        Me.BTadd.Text = "+"
        Me.BTadd.UseVisualStyleBackColor = False
        '
        'BTdivide
        '
        Me.BTdivide.BackColor = System.Drawing.Color.White
        Me.BTdivide.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTdivide.Location = New System.Drawing.Point(440, 121)
        Me.BTdivide.Name = "BTdivide"
        Me.BTdivide.Size = New System.Drawing.Size(50, 50)
        Me.BTdivide.TabIndex = 14
        Me.BTdivide.Text = "÷"
        Me.BTdivide.UseVisualStyleBackColor = False
        '
        'BTmultiply
        '
        Me.BTmultiply.BackColor = System.Drawing.Color.White
        Me.BTmultiply.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTmultiply.Location = New System.Drawing.Point(440, 177)
        Me.BTmultiply.Name = "BTmultiply"
        Me.BTmultiply.Size = New System.Drawing.Size(50, 50)
        Me.BTmultiply.TabIndex = 13
        Me.BTmultiply.Text = "*"
        Me.BTmultiply.UseVisualStyleBackColor = False
        '
        'BTsubtract
        '
        Me.BTsubtract.BackColor = System.Drawing.Color.White
        Me.BTsubtract.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTsubtract.Location = New System.Drawing.Point(440, 233)
        Me.BTsubtract.Name = "BTsubtract"
        Me.BTsubtract.Size = New System.Drawing.Size(50, 50)
        Me.BTsubtract.TabIndex = 12
        Me.BTsubtract.Text = "-"
        Me.BTsubtract.UseVisualStyleBackColor = False
        '
        'BTclearAll
        '
        Me.BTclearAll.BackColor = System.Drawing.Color.White
        Me.BTclearAll.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTclearAll.Location = New System.Drawing.Point(440, 65)
        Me.BTclearAll.Name = "BTclearAll"
        Me.BTclearAll.Size = New System.Drawing.Size(50, 50)
        Me.BTclearAll.TabIndex = 19
        Me.BTclearAll.Text = "C"
        Me.BTclearAll.UseVisualStyleBackColor = False
        '
        'BTclearCurrent
        '
        Me.BTclearCurrent.BackColor = System.Drawing.Color.White
        Me.BTclearCurrent.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTclearCurrent.Location = New System.Drawing.Point(384, 65)
        Me.BTclearCurrent.Name = "BTclearCurrent"
        Me.BTclearCurrent.Size = New System.Drawing.Size(50, 50)
        Me.BTclearCurrent.TabIndex = 18
        Me.BTclearCurrent.Text = "CE"
        Me.BTclearCurrent.UseVisualStyleBackColor = False
        '
        'BTe
        '
        Me.BTe.BackColor = System.Drawing.Color.White
        Me.BTe.Font = New System.Drawing.Font("Times New Roman", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTe.Location = New System.Drawing.Point(328, 65)
        Me.BTe.Name = "BTe"
        Me.BTe.Size = New System.Drawing.Size(50, 50)
        Me.BTe.TabIndex = 17
        Me.BTe.Text = "e"
        Me.BTe.UseVisualStyleBackColor = False
        '
        'BTpi
        '
        Me.BTpi.BackColor = System.Drawing.Color.White
        Me.BTpi.Font = New System.Drawing.Font("Times New Roman", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTpi.Location = New System.Drawing.Point(272, 65)
        Me.BTpi.Name = "BTpi"
        Me.BTpi.Size = New System.Drawing.Size(50, 50)
        Me.BTpi.TabIndex = 16
        Me.BTpi.Text = "π"
        Me.BTpi.UseVisualStyleBackColor = False
        '
        'BTposNegSwitch
        '
        Me.BTposNegSwitch.BackColor = System.Drawing.Color.White
        Me.BTposNegSwitch.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTposNegSwitch.Location = New System.Drawing.Point(496, 65)
        Me.BTposNegSwitch.Name = "BTposNegSwitch"
        Me.BTposNegSwitch.Size = New System.Drawing.Size(50, 50)
        Me.BTposNegSwitch.TabIndex = 23
        Me.BTposNegSwitch.Text = "±"
        Me.BTposNegSwitch.UseVisualStyleBackColor = False
        '
        'BTsqrt
        '
        Me.BTsqrt.BackColor = System.Drawing.Color.White
        Me.BTsqrt.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTsqrt.Location = New System.Drawing.Point(496, 121)
        Me.BTsqrt.Name = "BTsqrt"
        Me.BTsqrt.Size = New System.Drawing.Size(50, 50)
        Me.BTsqrt.TabIndex = 22
        Me.BTsqrt.Text = "√"
        Me.BTsqrt.UseVisualStyleBackColor = False
        '
        'BTneg1pow
        '
        Me.BTneg1pow.BackColor = System.Drawing.Color.White
        Me.BTneg1pow.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTneg1pow.Location = New System.Drawing.Point(496, 177)
        Me.BTneg1pow.Name = "BTneg1pow"
        Me.BTneg1pow.Size = New System.Drawing.Size(50, 50)
        Me.BTneg1pow.TabIndex = 21
        Me.BTneg1pow.Text = "x⁻¹"
        Me.BTneg1pow.UseVisualStyleBackColor = False
        '
        'BTsubmit
        '
        Me.BTsubmit.BackColor = System.Drawing.Color.White
        Me.BTsubmit.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTsubmit.Location = New System.Drawing.Point(496, 233)
        Me.BTsubmit.Name = "BTsubmit"
        Me.BTsubmit.Size = New System.Drawing.Size(50, 106)
        Me.BTsubmit.TabIndex = 20
        Me.BTsubmit.Text = "="
        Me.BTsubmit.UseVisualStyleBackColor = False
        '
        'BTtan
        '
        Me.BTtan.BackColor = System.Drawing.Color.White
        Me.BTtan.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTtan.Location = New System.Drawing.Point(186, 65)
        Me.BTtan.Name = "BTtan"
        Me.BTtan.Size = New System.Drawing.Size(80, 50)
        Me.BTtan.TabIndex = 26
        Me.BTtan.Text = "tan θ"
        Me.BTtan.UseVisualStyleBackColor = False
        '
        'BTcos
        '
        Me.BTcos.BackColor = System.Drawing.Color.White
        Me.BTcos.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTcos.Location = New System.Drawing.Point(100, 65)
        Me.BTcos.Name = "BTcos"
        Me.BTcos.Size = New System.Drawing.Size(80, 50)
        Me.BTcos.TabIndex = 27
        Me.BTcos.Text = "cos θ"
        Me.BTcos.UseVisualStyleBackColor = False
        '
        'BTsin
        '
        Me.BTsin.BackColor = System.Drawing.Color.White
        Me.BTsin.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTsin.Location = New System.Drawing.Point(14, 65)
        Me.BTsin.Name = "BTsin"
        Me.BTsin.Size = New System.Drawing.Size(80, 50)
        Me.BTsin.TabIndex = 28
        Me.BTsin.Text = "sin θ"
        Me.BTsin.UseVisualStyleBackColor = False
        '
        'BTlog
        '
        Me.BTlog.BackColor = System.Drawing.Color.White
        Me.BTlog.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTlog.Location = New System.Drawing.Point(100, 289)
        Me.BTlog.Name = "BTlog"
        Me.BTlog.Size = New System.Drawing.Size(80, 50)
        Me.BTlog.TabIndex = 29
        Me.BTlog.Text = "log"
        Me.BTlog.UseVisualStyleBackColor = False
        '
        'BTln
        '
        Me.BTln.BackColor = System.Drawing.Color.White
        Me.BTln.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTln.Location = New System.Drawing.Point(14, 121)
        Me.BTln.Name = "BTln"
        Me.BTln.Size = New System.Drawing.Size(80, 50)
        Me.BTln.TabIndex = 32
        Me.BTln.Text = "ln"
        Me.BTln.UseVisualStyleBackColor = False
        '
        'BTsq
        '
        Me.BTsq.BackColor = System.Drawing.Color.White
        Me.BTsq.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTsq.Location = New System.Drawing.Point(100, 121)
        Me.BTsq.Name = "BTsq"
        Me.BTsq.Size = New System.Drawing.Size(80, 50)
        Me.BTsq.TabIndex = 31
        Me.BTsq.Text = "x²"
        Me.BTsq.UseVisualStyleBackColor = False
        '
        'BTfactorial
        '
        Me.BTfactorial.BackColor = System.Drawing.Color.White
        Me.BTfactorial.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTfactorial.Location = New System.Drawing.Point(186, 121)
        Me.BTfactorial.Name = "BTfactorial"
        Me.BTfactorial.Size = New System.Drawing.Size(80, 50)
        Me.BTfactorial.TabIndex = 30
        Me.BTfactorial.Text = "n!"
        Me.BTfactorial.UseVisualStyleBackColor = False
        '
        'BTarcSin
        '
        Me.BTarcSin.BackColor = System.Drawing.Color.White
        Me.BTarcSin.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTarcSin.Location = New System.Drawing.Point(14, 177)
        Me.BTarcSin.Name = "BTarcSin"
        Me.BTarcSin.Size = New System.Drawing.Size(80, 50)
        Me.BTarcSin.TabIndex = 33
        Me.BTarcSin.Text = "sin θ°"
        Me.BTarcSin.UseVisualStyleBackColor = False
        '
        'BTarcCos
        '
        Me.BTarcCos.BackColor = System.Drawing.Color.White
        Me.BTarcCos.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTarcCos.Location = New System.Drawing.Point(14, 235)
        Me.BTarcCos.Name = "BTarcCos"
        Me.BTarcCos.Size = New System.Drawing.Size(80, 50)
        Me.BTarcCos.TabIndex = 34
        Me.BTarcCos.Text = "cos θ°"
        Me.BTarcCos.UseVisualStyleBackColor = False
        '
        'BTarcTan
        '
        Me.BTarcTan.BackColor = System.Drawing.Color.White
        Me.BTarcTan.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTarcTan.Location = New System.Drawing.Point(14, 289)
        Me.BTarcTan.Name = "BTarcTan"
        Me.BTarcTan.Size = New System.Drawing.Size(80, 50)
        Me.BTarcTan.TabIndex = 35
        Me.BTarcTan.Text = "tan θ°"
        Me.BTarcTan.UseVisualStyleBackColor = False
        '
        'BTcb
        '
        Me.BTcb.BackColor = System.Drawing.Color.White
        Me.BTcb.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTcb.Location = New System.Drawing.Point(100, 233)
        Me.BTcb.Name = "BTcb"
        Me.BTcb.Size = New System.Drawing.Size(80, 50)
        Me.BTcb.TabIndex = 39
        Me.BTcb.Text = "x³"
        Me.BTcb.UseVisualStyleBackColor = False
        '
        'BTcbrt
        '
        Me.BTcbrt.BackColor = System.Drawing.Color.White
        Me.BTcbrt.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTcbrt.Location = New System.Drawing.Point(186, 233)
        Me.BTcbrt.Name = "BTcbrt"
        Me.BTcbrt.Size = New System.Drawing.Size(80, 50)
        Me.BTcbrt.TabIndex = 38
        Me.BTcbrt.Text = "∛x"
        Me.BTcbrt.UseVisualStyleBackColor = False
        '
        'BTpowY
        '
        Me.BTpowY.BackColor = System.Drawing.Color.White
        Me.BTpowY.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTpowY.Location = New System.Drawing.Point(100, 177)
        Me.BTpowY.Name = "BTpowY"
        Me.BTpowY.Size = New System.Drawing.Size(80, 50)
        Me.BTpowY.TabIndex = 37
        Me.BTpowY.Text = "xʸ"
        Me.BTpowY.UseVisualStyleBackColor = False
        '
        'BTrootY
        '
        Me.BTrootY.BackColor = System.Drawing.Color.White
        Me.BTrootY.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTrootY.Location = New System.Drawing.Point(186, 177)
        Me.BTrootY.Name = "BTrootY"
        Me.BTrootY.Size = New System.Drawing.Size(80, 50)
        Me.BTrootY.TabIndex = 36
        Me.BTrootY.Text = "ʸ√x"
        Me.BTrootY.UseVisualStyleBackColor = False
        '
        'BTpowTen
        '
        Me.BTpowTen.BackColor = System.Drawing.Color.White
        Me.BTpowTen.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTpowTen.Location = New System.Drawing.Point(186, 289)
        Me.BTpowTen.Name = "BTpowTen"
        Me.BTpowTen.Size = New System.Drawing.Size(80, 50)
        Me.BTpowTen.TabIndex = 40
        Me.BTpowTen.Text = "10ˣ"
        Me.BTpowTen.UseVisualStyleBackColor = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.Scientific_Calculator.My.Resources.Resources.Question_Block_NSMB
        Me.PictureBox2.Location = New System.Drawing.Point(552, 177)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(211, 162)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 42
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Scientific_Calculator.My.Resources.Resources.simpsons_2_2000
        Me.PictureBox1.Location = New System.Drawing.Point(552, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(211, 159)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 41
        Me.PictureBox1.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDark
        Me.ClientSize = New System.Drawing.Size(771, 350)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.BTpowTen)
        Me.Controls.Add(Me.BTcb)
        Me.Controls.Add(Me.BTcbrt)
        Me.Controls.Add(Me.BTpowY)
        Me.Controls.Add(Me.BTrootY)
        Me.Controls.Add(Me.BTarcTan)
        Me.Controls.Add(Me.BTarcCos)
        Me.Controls.Add(Me.BTarcSin)
        Me.Controls.Add(Me.BTln)
        Me.Controls.Add(Me.BTsq)
        Me.Controls.Add(Me.BTfactorial)
        Me.Controls.Add(Me.BTlog)
        Me.Controls.Add(Me.BTsin)
        Me.Controls.Add(Me.BTcos)
        Me.Controls.Add(Me.BTtan)
        Me.Controls.Add(Me.BTposNegSwitch)
        Me.Controls.Add(Me.BTsqrt)
        Me.Controls.Add(Me.BTneg1pow)
        Me.Controls.Add(Me.BTsubmit)
        Me.Controls.Add(Me.BTclearAll)
        Me.Controls.Add(Me.BTclearCurrent)
        Me.Controls.Add(Me.BTe)
        Me.Controls.Add(Me.BTpi)
        Me.Controls.Add(Me.BTadd)
        Me.Controls.Add(Me.BTdivide)
        Me.Controls.Add(Me.BTmultiply)
        Me.Controls.Add(Me.BTsubtract)
        Me.Controls.Add(Me.BTdecimalpnt)
        Me.Controls.Add(Me.BTnum0)
        Me.Controls.Add(Me.BTnum9)
        Me.Controls.Add(Me.BTnum8)
        Me.Controls.Add(Me.BTnum7)
        Me.Controls.Add(Me.BTnum6)
        Me.Controls.Add(Me.BTnum5)
        Me.Controls.Add(Me.BTnum4)
        Me.Controls.Add(Me.BTnum3)
        Me.Controls.Add(Me.BTnum2)
        Me.Controls.Add(Me.BTnum1)
        Me.Controls.Add(Me.TextBox1)
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "Scientific Calculator"
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents BTnum1 As Button
    Friend WithEvents BTnum2 As Button
    Friend WithEvents BTnum3 As Button
    Friend WithEvents BTnum6 As Button
    Friend WithEvents BTnum5 As Button
    Friend WithEvents BTnum4 As Button
    Friend WithEvents BTnum9 As Button
    Friend WithEvents BTnum8 As Button
    Friend WithEvents BTnum7 As Button
    Friend WithEvents BTnum0 As Button
    Friend WithEvents BTdecimalpnt As Button
    Friend WithEvents BTadd As Button
    Friend WithEvents BTdivide As Button
    Friend WithEvents BTmultiply As Button
    Friend WithEvents BTsubtract As Button
    Friend WithEvents BTclearAll As Button
    Friend WithEvents BTclearCurrent As Button
    Friend WithEvents BTe As Button
    Friend WithEvents BTpi As Button
    Friend WithEvents BTposNegSwitch As Button
    Friend WithEvents BTsqrt As Button
    Friend WithEvents BTneg1pow As Button
    Friend WithEvents BTsubmit As Button
    Friend WithEvents BTtan As Button
    Friend WithEvents BTcos As Button
    Friend WithEvents BTsin As Button
    Friend WithEvents BTlog As Button
    Friend WithEvents BTln As Button
    Friend WithEvents BTsq As Button
    Friend WithEvents BTfactorial As Button
    Friend WithEvents BTarcSin As Button
    Friend WithEvents BTarcCos As Button
    Friend WithEvents BTarcTan As Button
    Friend WithEvents BTcb As Button
    Friend WithEvents BTcbrt As Button
    Friend WithEvents BTpowY As Button
    Friend WithEvents BTrootY As Button
    Friend WithEvents BTpowTen As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
End Class
