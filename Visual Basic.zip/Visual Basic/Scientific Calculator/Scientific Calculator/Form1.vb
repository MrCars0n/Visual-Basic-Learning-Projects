﻿Public Class Form1

    Dim oldNumber As Double
    Dim operation As String

    Private Sub BTnum_Click(sender As Object, e As EventArgs) Handles BTnum1.Click,
            BTnum2.Click, BTnum3.Click, BTnum4.Click,
            BTnum5.Click, BTnum6.Click, BTnum7.Click,
            BTnum8.Click, BTnum9.Click, BTnum0.Click
        If Val(TextBox1.Text) = 0 And Not TextBox1.Text.Contains(".") Then TextBox1.Text = ""
        TextBox1.Text = TextBox1.Text + sender.text
    End Sub

    Private Sub BTnum_MouseEnter(sender As Object, e As EventArgs) Handles BTnum1.MouseEnter,
            BTnum2.MouseEnter, BTnum3.MouseEnter, BTnum4.MouseEnter,
            BTnum5.MouseEnter, BTnum6.MouseEnter, BTnum7.MouseEnter,
            BTnum8.MouseEnter, BTnum9.MouseEnter, BTnum0.MouseEnter
        sender.BackColor = Color.Black
        sender.ForeColor = Color.White
    End Sub

    Private Sub BTnum_MouseLeave(sender As Object, e As EventArgs) Handles BTnum1.MouseLeave,
            BTnum2.MouseLeave, BTnum3.MouseLeave, BTnum4.MouseLeave,
            BTnum5.MouseLeave, BTnum6.MouseLeave, BTnum7.MouseLeave,
            BTnum8.MouseLeave, BTnum9.MouseLeave, BTnum0.MouseLeave
        sender.BackColor = Color.White
        sender.ForeColor = Color.Black
    End Sub

    Private Sub BTsqrt_Click(sender As Object, e As EventArgs) Handles BTsqrt.Click
        TextBox1.Text = Math.Sqrt(Val(TextBox1.Text))
    End Sub

    Private Sub BTlog_Click(sender As Object, e As EventArgs) Handles BTlog.Click
        ' Math.log10 is "common log" -- the log button
        ' Math.log is "natural log" -- to ln button
        TextBox1.Text = Math.Log10(Val(TextBox1.Text))
    End Sub

    Private Sub BTln_Click(sender As Object, e As EventArgs) Handles BTln.Click
        TextBox1.Text = Math.Log(Val(TextBox1.Text))
    End Sub

    Private Sub BTsin_Click(sender As Object, e As EventArgs) Handles BTsin.Click
        TextBox1.Text = Math.Sin(Val(TextBox1.Text))
    End Sub

    Private Sub BTcos_Click(sender As Object, e As EventArgs) Handles BTcos.Click
        TextBox1.Text = Math.Cos(Val(TextBox1.Text))
    End Sub

    Private Sub BTtan_Click(sender As Object, e As EventArgs) Handles BTtan.Click
        TextBox1.Text = Math.Tan(Val(TextBox1.Text))
    End Sub

    Private Sub BTsq_Click(sender As Object, e As EventArgs) Handles BTsq.Click
        TextBox1.Text = Val(TextBox1.Text) ^ 2
    End Sub

    Private Sub BTcb_Click(sender As Object, e As EventArgs) Handles BTcb.Click
        TextBox1.Text = Val(TextBox1.Text) ^ 3
    End Sub

    Private Sub BTarcSin_Click(sender As Object, e As EventArgs) Handles BTarcSin.Click
        TextBox1.Text = Math.Asin(Val(TextBox1.Text))
    End Sub

    Private Sub BTarcCos_Click(sender As Object, e As EventArgs) Handles BTarcCos.Click
        TextBox1.Text = Math.Acos(Val(TextBox1.Text))
    End Sub

    Private Sub BTarcTan_Click(sender As Object, e As EventArgs) Handles BTarcTan.Click
        TextBox1.Text = Math.Atan(Val(TextBox1.Text))
    End Sub

    Private Sub BTpowTen_Click(sender As Object, e As EventArgs) Handles BTpowTen.Click
        TextBox1.Text = 10 ^ Val(TextBox1.Text)
    End Sub

    Private Sub BTcbrt_Click(sender As Object, e As EventArgs) Handles BTcbrt.Click
        TextBox1.Text = Val(TextBox1.Text) ^ (1 / 3)
    End Sub

    Private Sub BTadd_Click(sender As Object, e As EventArgs) Handles BTadd.Click
        oldNumber = Val(TextBox1.Text)
        TextBox1.Text = ""
        operation = "add"
    End Sub

    Private Sub BTsubtract_Click(sender As Object, e As EventArgs) Handles BTsubtract.Click
        oldNumber = Val(TextBox1.Text)
        TextBox1.Text = ""
        operation = "subtract"
    End Sub

    Private Sub BTmultiply_Click(sender As Object, e As EventArgs) Handles BTmultiply.Click
        oldNumber = Val(TextBox1.Text)
        TextBox1.Text = ""
        operation = "multiply"
    End Sub

    Private Sub BTdivide_Click(sender As Object, e As EventArgs) Handles BTdivide.Click
        oldNumber = Val(TextBox1.Text)
        TextBox1.Text = ""
        operation = "divide"
    End Sub

    Private Sub BTsubmit_Click(sender As Object, e As EventArgs) Handles BTsubmit.Click
        If operation = "add" Then
            TextBox1.Text = oldNumber + Val(TextBox1.Text)
        ElseIf operation = "subtract" Then
            TextBox1.Text = oldNumber - Val(TextBox1.Text)
        ElseIf operation = "multiply" Then
            TextBox1.Text = oldNumber * Val(TextBox1.Text)
        ElseIf operation = "divide" Then
            TextBox1.Text = oldNumber / Val(TextBox1.Text)
        ElseIf operation = "rootY" Then
            TextBox1.Text = Val(TextBox1.Text) ^ (1 / oldNumber)
        ElseIf operation = "powY" Then
            TextBox1.Text = oldNumber ^ Val(TextBox1.Text)
        End If
    End Sub

    Private Sub BTclearAll_Click(sender As Object, e As EventArgs) Handles BTclearAll.Click
        TextBox1.Text = ""
        operation = ""
        oldNumber = Nothing
    End Sub

    Private Sub BTclearCurrent_Click(sender As Object, e As EventArgs) Handles BTclearCurrent.Click
        TextBox1.Text = ""
    End Sub

    Private Sub BTposNegSwitch_Click(sender As Object, e As EventArgs) Handles BTposNegSwitch.Click
        If Val(TextBox1.Text) > 0 Then
            TextBox1.Text = -Val(TextBox1.Text)
        ElseIf Val(TextBox1.Text) < 0 Then
            TextBox1.Text = Math.Abs(Val(TextBox1.Text))
        End If
    End Sub

    Private Sub BTpi_Click(sender As Object, e As EventArgs) Handles BTpi.Click
        If Val(TextBox1.Text) = 0 Then TextBox1.Text = ""

        TextBox1.Text = Str(Math.PI)
    End Sub

    Private Sub BTneg1pow_Click(sender As Object, e As EventArgs) Handles BTneg1pow.Click
        TextBox1.Text = Val(TextBox1.Text) ^ -1
    End Sub

    Private Sub BTe_Click(sender As Object, e As EventArgs) Handles BTe.Click
        If Val(TextBox1.Text) = 0 Then TextBox1.Text = ""

        TextBox1.Text = Str(Math.E)
    End Sub

    Private Sub BTrootY_Click(sender As Object, e As EventArgs) Handles BTrootY.Click
        oldNumber = Val(TextBox1.Text)
        TextBox1.Text = ""
        operation = "rootY"
    End Sub

    Private Sub BTpowY_Click(sender As Object, e As EventArgs) Handles BTpowY.Click
        oldNumber = Val(TextBox1.Text)
        TextBox1.Text = ""
        operation = "powY"
    End Sub

    Private Sub BTdecimalpnt_Click(sender As Object, e As EventArgs) Handles BTdecimalpnt.Click
        If Val(TextBox1.Text) = 0 Then TextBox1.Text = ""
        If Not TextBox1.Text.Contains(".") Then
            TextBox1.Text = TextBox1.Text + sender.text
        End If
    End Sub

    Private Sub BTfactorial_Click(sender As Object, e As EventArgs) Handles BTfactorial.Click

        Dim total As Integer
        total = 1

        For n = Val(TextBox1.Text) To 1 Step -1
            total = total * n
        Next

        TextBox1.Text = total
    End Sub
End Class
