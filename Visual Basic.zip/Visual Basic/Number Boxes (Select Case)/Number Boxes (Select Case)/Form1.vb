﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Randomize()
        Me.BackColor = Color.FromArgb(Int(Rnd() * 255) + 1, Int(Rnd() * 255) + 1, Int(Rnd() * 255) + 1)
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        ' This code will get every object (control) on your form
        For Each c As Control In Me.Controls
            ' We can limit the choices of which type of object
            ' (In this case, we only change the LABEL backgrounds)
            If c.GetType Is GetType(Label) Then
                c.BackColor = Color.White
            End If
        Next

        ' Select case is an alternative to if-then
        Dim num As Integer
        num = Int(Rnd() * 10) + 1

        Select Case num
            Case 1
                Label1.BackColor = Color.Yellow
            Case 2
                Label2.BackColor = Color.Yellow
            Case 3
                Label3.BackColor = Color.Yellow
            Case 4
                Label4.BackColor = Color.Yellow
            Case 5
                Label5.BackColor = Color.Yellow
            Case 6
                Label6.BackColor = Color.Yellow
            Case 7
                Label7.BackColor = Color.Yellow
            Case 8
                Label8.BackColor = Color.Yellow
            Case 9
                Label9.BackColor = Color.Yellow

        End Select
    End Sub
End Class
