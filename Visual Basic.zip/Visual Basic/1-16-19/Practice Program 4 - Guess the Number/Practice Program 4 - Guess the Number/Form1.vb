﻿Public Class Form1

    Dim number As Integer
    Dim count As Integer

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim guess As Integer
        guess = TextBox1.Text

        If guess > number Then
            Label1.Text = "TOO HIGH"
        ElseIf guess < number Then
            Label1.Text = "TOO LOW"
        Else
            Label1.Text = "CORRECT!"
        End If

        count = count + 1
        Button1.Text = "Number of Tries:" + Str(count)
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Randomize()
        number = Int(Rnd() * 100) + 1

    End Sub
End Class
