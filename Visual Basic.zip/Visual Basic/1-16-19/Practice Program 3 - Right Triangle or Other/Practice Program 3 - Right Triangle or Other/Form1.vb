﻿Public Class Form1
    Dim a, b, c As Integer
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        a = TextBox1.Text
        b = TextBox2.Text
        c = TextBox3.Text

        If (a ^ 2) + (b ^ 2) = (c ^ 2) Then
            TextBox1.BackColor = Color.Green
            TextBox2.BackColor = Color.Green
            TextBox3.BackColor = Color.Green
        Else
            TextBox1.BackColor = Color.Red
            TextBox2.BackColor = Color.Red
            TextBox3.BackColor = Color.Red
        End If
    End Sub
End Class
