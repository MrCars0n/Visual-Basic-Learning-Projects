﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim number As Integer
        number = TextBox1.Text
        If number > 0 Then
            Label1.Text = "Your Number Is Positive"
        ElseIf number < 0 Then
            Label1.Text = "Your Number Is Negative"
        ElseIf number = 0 Then
            Label1.Text = "Your Number Is Zero"
        End If
    End Sub
End Class
