﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Button1.Text = Button1.Text + 1
        If Button1.Text = 20 Then
            Button1.Enabled = False
        End If
    End Sub
End Class
