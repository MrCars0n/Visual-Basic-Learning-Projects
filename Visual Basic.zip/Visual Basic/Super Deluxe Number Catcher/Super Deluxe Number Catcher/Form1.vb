﻿Public Class Form1

    Dim startTime As Date
    Dim result As TimeSpan
    'Dim fontList As List(Of String)({"Comic Sans MS", "Test"})

    Dim number(0 To 9) As Label
    Dim count, XPSPEED, XPdx, XPdy, dy(0 To 9), dx(0 To 9) As Integer

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Randomize()
        count = 1
        XPSPEED = 5
        XPdx = Int(Rnd() * 11) - 5
        XPdy = Int(Rnd() * 11) - 5

        For n = 0 To 9
            number(n) = New Label
            number(n).AutoSize = False
            number(n).Width = 100
            number(n).Height = 100
            number(n).Left = Int(Rnd() * (Me.Width - 100))
            number(n).Top = Int(Rnd() * (Me.Height - 100))
            number(n).BackColor = Color.FromArgb(Int(Rnd() * 256), Int(Rnd() * 256), Int(Rnd() * 256))
            number(n).ForeColor = Color.FromArgb(Int(Rnd() * 256), Int(Rnd() * 256), Int(Rnd() * 256))
            number(n).Font = New Font("Comic Sans MS", 20)
            number(n).Text = n + 1
            number(n).TextAlign = ContentAlignment.MiddleCenter

            dx(n) = Int(Rnd() * 11) - 5
            dy(n) = Int(Rnd() * 11) - 5

            Me.Controls.Add(number(n))

            AddHandler number(n).Click, AddressOf number_click
        Next

        startTime = Now
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        result = Now - startTime
        Label1.Text = "Time: " + Str(FormatNumber(result.TotalSeconds, 2))

        For n = 0 To 9
            number(n).Left = number(n).Left + dx(n)
            number(n).Top = number(n).Top + dy(n)

            If number(n).Top < 0 Then dy(n) = dy(n) * -1
            If number(n).Bottom > 1080 Then dy(n) = dy(n) * -1

            If number(n).Left < 0 Then dx(n) = dx(n) * -1
            If number(n).Right > 1920 Then dx(n) = dx(n) * -1
        Next

        PictureBox1.Left = PictureBox1.Left + XPdx
        PictureBox1.Top = PictureBox1.Top + XPdy

        If PictureBox1.Top < 0 Then XPdy = XPdy * -1
        If PictureBox1.Bottom > 1080 Then XPdy = XPdy * -1

        If PictureBox1.Left < 0 Then XPdx = XPdx * -1
        If PictureBox1.Right > 1920 Then XPdx = XPdx * -1
    End Sub

    Private Sub number_click(sender As Object, e As EventArgs)
        If sender.Text = count Then
            sender.visible = False
            count = count + 1
            Me.BackColor = Color.FromArgb(Int(Rnd() * 256), Int(Rnd() * 256), Int(Rnd() * 256))
            'PictureBox1.Width = PictureBox1.Width + 100

            If count = 11 Then
                Timer1.Enabled = False
                MsgBox("You Win! Your time was" + Str(FormatNumber(result.TotalSeconds, 2)) + " seconds")
            End If
        End If
    End Sub

    Private Sub PictureBox1_MouseHover(sender As Object, e As EventArgs) Handles PictureBox1.MouseHover
        For n = 0 To 9
            dx(n) = 0
            dy(n) = 0
            XPdy = 0
            XPdx = 0
        Next
        MsgBox("WINDOWS XP INSTALLER ERROR!" + Environment.NewLine + "ERROR 42: SYNTAX INCORRECT AT LINE 28")
        End
    End Sub
End Class
